function mat = read_mat(path)
    mat = csvread(path, 1, 1);
end
